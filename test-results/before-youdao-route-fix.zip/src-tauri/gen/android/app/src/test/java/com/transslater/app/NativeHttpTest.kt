package com.transslater.app

import java.net.ServerSocket
import java.net.URL
import java.util.zip.GZIPOutputStream
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors
import org.junit.Assert.*
import org.junit.Test

class NativeHttpTest {
  @Test fun getsEncodedQueriesHeadersAndGzipWithoutLosingUnicode() {
    ServerSocket(0).use { server ->
      val worker = Executors.newSingleThreadExecutor()
      val request = worker.submit<String> {
        server.accept().use { socket ->
          val reader = socket.getInputStream().bufferedReader()
          val headers = generateSequence { reader.readLine()?.takeIf { it.isNotEmpty() } }.joinToString("\n")
          val out = ByteArrayOutputStream()
          GZIPOutputStream(out).use { it.write("{\"translation\":[\"你好\"]}".toByteArray()) }
          val body = out.toByteArray()
          socket.getOutputStream().write(("HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Encoding: gzip\r\nContent-Length: ${body.size}\r\nConnection: close\r\n\r\n").toByteArray() + body)
          headers
        }
      }
      try {
        val response = NativeHttp.get(URL("http://127.0.0.1:${server.localPort}/?q=hello%20world"), true, "https://dict.youdao.com/")
        assertEquals(200, response.status)
        assertTrue(response.body.contains("你好"))
        assertTrue(request.get().contains("q=hello%20world"))
        assertTrue(request.get().contains("Referer: https://dict.youdao.com/"))
      } finally { worker.shutdownNow() }
    }
  }

  @Test fun preservesHttpFailuresAndExplainsConnectionFailures() {
    ServerSocket(0).use { server ->
      val worker = Executors.newSingleThreadExecutor()
      val served = worker.submit {
        server.accept().use { socket ->
          val reader = socket.getInputStream().bufferedReader()
          while (!reader.readLine().isNullOrEmpty()) { }
          socket.getOutputStream().write("HTTP/1.1 429 Too Many Requests\r\nContent-Length: 4\r\nConnection: close\r\n\r\nslow".toByteArray())
        }
      }
      try {
        val response = NativeHttp.get(URL("http://127.0.0.1:${server.localPort}"), true)
        assertEquals(429, response.status)
        assertEquals("slow", response.body)
        served.get()
      } finally { worker.shutdownNow() }
    }
    assertTrue(NativeHttp.describe(java.net.UnknownHostException(), "example.com").contains("DNS"))
    assertTrue(NativeHttp.describe(javax.net.ssl.SSLHandshakeException("failed"), "example.com").contains("证书"))
    assertTrue(NativeHttp.describe(java.net.SocketTimeoutException(), "example.com").contains("超时"))
    assertTrue(NativeHttp.describe(java.net.SocketException("Permission denied"), "example.com").contains("系统阻止"))
  }

  @Test fun liveProviderConnections() {
    org.junit.Assume.assumeTrue(System.getProperty("transslater.live") == "true")
    val queries = listOf(
      "https://dict.youdao.com/jsonapi?q=hello" to true,
      "https://aidemo.youdao.com/trans?q=Hello%20world&from=en&to=zh-CHS" to true,
      "https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=zh-CN&dt=t&q=hello" to false
    )
    for ((address, direct) in queries) {
      val url = URL(address)
      val response = NativeHttp.get(url, direct, "https://dict.youdao.com/")
      assertTrue("${url.host}: HTTP ${response.status}", response.status == 200 || response.status == 429)
      assertTrue("${url.host}: empty response", response.body.isNotBlank())
      println("${url.host}: HTTP ${response.status}, ${response.body.length} characters")
    }
  }
}
